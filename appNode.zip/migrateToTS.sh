# Instalamos las dependencias de typescript para el body parser, express y node
npm install --save-dev @types/body-parser @types/express ts-node nodemon typescript
# Inicializamos la configuración de typescript en el proyecto
npx tsc -init
