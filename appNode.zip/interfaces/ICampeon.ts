
export default interface ICampeon {
    id: number | null,
    piloto: string,
    titulos: Array<any>,
    equipo: string
}